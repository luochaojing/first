//
//  LockView.m
//  手势解锁练习
//
//  Created by 孔繁武 on 15/11/20.
//  Copyright © 2015年 孔繁武. All rights reserved.
//

#import "LockView.h"
#import "ViewController.h"
#define kbuttonCount 9

@interface LockView ()
@property (nonatomic,strong) NSArray *btnArr;

@property (nonatomic,strong) NSMutableArray  *selectedBtnArr;

@property (nonatomic,assign) CGPoint currentPoint;

@property (nonatomic,assign) BOOL result; // 解锁结果

@property (nonatomic,strong) ViewController * con;

@property (nonatomic,strong) NSString * currentPassword;

@end

@implementation LockView

- (NSMutableArray *)selectedBtnArr{
    
    if (nil == _selectedBtnArr) {
        _selectedBtnArr = [NSMutableArray array];
    }
    return _selectedBtnArr;
}

- (NSArray *)btnArr{
    
    if (nil == _btnArr) {
        
        NSMutableArray *arr = [NSMutableArray array];
        
        for (int i = 0; i < kbuttonCount; i++) {
        
            UIButton *btn = [[UIButton alloc] init];
            btn.tag = i; // 设置标记，(密码);
            
            [btn setBackgroundImage:[UIImage imageNamed:@"gesture_node_normal"] forState:UIControlStateNormal];
            [btn setBackgroundImage:[UIImage imageNamed:@"gesture_node_highlighted"] forState:UIControlStateSelected];
            [btn setBackgroundImage:[UIImage imageNamed:@"gesture_node_error"] forState:UIControlStateHighlighted];
            
            [arr addObject:btn];
        }
        _btnArr = arr;
    }
    return _btnArr;
}


- (void)layoutSubviews{
    [super layoutSubviews];
    
    int column = 3;
    CGFloat btnW = 74;
    CGFloat btnH = 74;
    CGFloat btnX = 0;
    CGFloat btnY =0;
    CGFloat margin = (self.frame.size.width - column * btnW) / (column + 1);
    
    for (int i = 0; i < kbuttonCount; i++) {
        
        btnX = margin + (i % column) * (margin + btnW);
        btnY = margin + (i / column) * (margin + btnH);
        
        UIButton *btn = self.btnArr[i];
        btn.frame = CGRectMake(btnX, btnY, btnW, btnH);
        btn.userInteractionEnabled = NO;   // 禁止btn与用户交互
        
        [self addSubview:btn];
    }
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    UITouch *touch = touches.anyObject;
    // 获取触摸的点
    CGPoint p = [touch locationInView:touch.view];
    
    // 循环数组，判断当前触摸的点在哪个按钮的范围内。然后将这个按钮放在保存触摸按钮的数组中
    for (int i = 0; i < self.btnArr.count; i++) {

        if (CGRectContainsPoint([self.btnArr[i] frame], p)) {
            
            // 设置按钮为选中状态
            [self.btnArr[i] setSelected:YES];
            
            // 放到选中按钮的数组中
            if (![self.selectedBtnArr containsObject:self.btnArr[i]]) {
                [self.selectedBtnArr addObject:self.btnArr[i]];
            }
        }
    }
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
//    [self setNeedsDisplay];
    
    UITouch *touch = touches.anyObject;
    // 获取触摸的点
    CGPoint p = [touch locationInView:touch.view];
    
    self.currentPoint = p; // 保存当前触摸的点，用来画线
    
    
    // 循环数组，判断当前触摸的点在哪个按钮的范围内。然后将这个按钮放在保存触摸按钮的数组中
    for (int i = 0; i < self.btnArr.count; i++) {
        
        //点p是否在点i的范围之内
        if (CGRectContainsPoint([self.btnArr[i] frame], p)) {
            // 设置按钮为选中状态 - 可以直接调用？不判断类型吗
            [self.btnArr[i] setSelected:YES];
            
            //[self.btnArr[i] addObject:[[UIButton alloc]init]];
            
            // 放到选中按钮的数组中
            if (![self.selectedBtnArr containsObject:self.btnArr[i]]) {
                [self.selectedBtnArr addObject:self.btnArr[i]];
            }
        }
    }
    
    [self setNeedsDisplay];
}

// 停止触摸方法
- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    // 离开的时候，让线画到选中按钮数组中最后一个按钮的中心， 再重绘一下
    self.currentPoint = [[self.selectedBtnArr lastObject] center];
    [self setNeedsDisplay];
    
    NSString *passWord = @"";
    // 让所有按钮状态为错误状态
    for (UIButton *btn in self.selectedBtnArr) {
        
        passWord = [passWord stringByAppendingString:[NSString stringWithFormat:@"%ld",btn.tag]];
//        [btn setHighlighted:YES];
//        [btn setSelected:NO];
    }
    
    self.userInteractionEnabled = NO;   // 禁止用户交互
    
    // 1.5秒后，恢复交互，并且清空选中按钮的数组，取消画线
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        [self clear];
        self.userInteractionEnabled = YES;
        
    });

    
    // 判断是否实现判断密码的代理方法
    if ([self.delegate respondsToSelector:@selector(comparePassWord: withPassWord:)]) {
        
        self.result = [self.delegate comparePassWord:self withPassWord:passWord];
        
        if (self.result) {
            NSLog(@"密码正确");

            for (UIButton *btn in self.selectedBtnArr) {
                [btn setSelected:YES];
            }
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"恭喜你，密码正确" message:@"~~~ SUCCESS ~~~" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            
            [alert show];
            
        }else{
            NSLog(@"密码错误");
            for (UIButton *btn in self.selectedBtnArr) {
                [btn setHighlighted:YES];
                [btn setSelected:NO];
            }
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"密码错误！" message:@"请重新输入···" delegate:nil cancelButtonTitle:@"取消" otherButtonTitles:nil, nil];
            
            [alert show];
        }
    }
    
    // --------- 在屏幕上方显示图片,截图
    [self printScreen];
}

#pragma mark -- 清除所有选中
- (void)clear{
    
    for (UIButton *btn in self.selectedBtnArr) {
        
        btn.highlighted = NO;
        btn.selected = NO;
    }
    
    [self.selectedBtnArr removeAllObjects];
    [self setNeedsDisplay];
}

#pragma mark -- 截图方法
- (void)printScreen{
    UIGraphicsBeginImageContextWithOptions(self.bounds.size, NO, 0.0);  // 开启一个上下文
    
    CGContextRef context = UIGraphicsGetCurrentContext();   // 获取上下文对象
    
    [self.layer renderInContext:context];    // 截屏
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();   // 从上下文上获取图片
    
    UIGraphicsEndPDFContext();     // 关闭上下文
    
    // 是否实现显示图片的代理方法
    if ([self.delegate respondsToSelector:@selector(drawImageUp: withImage:)]) {
        
        [self.delegate drawImageUp:self withImage:image];
    }
}


#pragma mark -- 画线方法
 - (void)drawRect:(CGRect)rect {
     
//     if (self.selectedBtnArr.count == 0) {
//         return;
//     }
     
     UIBezierPath *path = [UIBezierPath bezierPath];
     
     for (int i = 0; i < self.selectedBtnArr.count; i++) {
         
         if (i == 0) {
             [path moveToPoint:[self.selectedBtnArr[i] center]];
         }else{
             [path addLineToPoint:[self.selectedBtnArr[i] center]];
        }
     }
     
     // 当手指没有触摸到按钮的时候，也需要画线
     if (self.selectedBtnArr.count) {
         [path addLineToPoint:self.currentPoint];
     }
     
     [[UIColor whiteColor] set];
     
     [path stroke];
     
 }
 
@end










