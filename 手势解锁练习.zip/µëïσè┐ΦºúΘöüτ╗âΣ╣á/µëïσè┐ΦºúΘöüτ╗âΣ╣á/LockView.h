//
//  LockView.h
//  手势解锁练习
//
//  Created by 孔繁武 on 15/11/20.
//  Copyright © 2015年 孔繁武. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LockView;

@protocol LockViewDelegate <NSObject>

- (BOOL)comparePassWord:(LockView *)lockView withPassWord:(NSString *)passWord;

- (void)drawImageUp:(LockView *)lockView withImage:(UIImage *)image;

@end

@interface LockView : UIView

@property (nonatomic,assign) id<LockViewDelegate> delegate;

@end
