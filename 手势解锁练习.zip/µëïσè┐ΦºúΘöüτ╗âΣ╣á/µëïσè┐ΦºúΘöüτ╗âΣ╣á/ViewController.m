//
//  ViewController.m
//  手势解锁练习
//
//  Created by 孔繁武 on 15/11/20.
//  Copyright © 2015年 孔繁武. All rights reserved.
//

#import "ViewController.h"
#import "LockView.h"

@interface ViewController () <LockViewDelegate>

@property (weak, nonatomic) IBOutlet UIImageView *upImage; // 屏幕上方显示的imageView
@property (weak, nonatomic) IBOutlet LockView *lockView;  // 显示手势的view

@property (nonatomic,strong) NSString *password;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.password = @"012";
    
    // 添加背景图片
    self.view.layer.contents = (__bridge id)([UIImage imageNamed:@"Home_refresh_bg"].CGImage);
    
    // 设置代理
    LockView *lock = [[LockView alloc] init];
    lock.delegate = self;
    
    self.lockView.delegate = self;
}

// 代理方法，判断控制器
- (BOOL)comparePassWord:(LockView *)lockView withPassWord:(NSString *)passWord{
    
    if ([passWord isEqualToString:self.password]) {
        return YES;
    }else{
        return NO;
    }
}

-(void)drawImageUp:(LockView *)lockView withImage:(UIImage *)image{
    
    self.upImage.image = image;
    
}

- (UIStatusBarStyle)preferredStatusBarStyle{
    
    return UIStatusBarStyleLightContent;
}

@end







