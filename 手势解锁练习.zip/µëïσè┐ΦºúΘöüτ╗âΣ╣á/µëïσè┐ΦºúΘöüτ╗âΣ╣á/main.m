//
//  main.m
//  手势解锁练习
//
//  Created by 孔繁武 on 15/11/20.
//  Copyright © 2015年 孔繁武. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
